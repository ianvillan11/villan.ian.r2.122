
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.Comparator;

public class Inventario <T> implements Almacenable<T>,Serializable{
    
    private List<T> lista;
    
    public Inventario(){
        this.lista = new ArrayList<>();
    }
    
    @Override
    public void agregar(T elemento) {
        lista.add(elemento);
    }
    
    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        for (int i = 0; i < lista.size(); i++) {
            if (criterio.test(lista.get(i))) {
                lista.remove(i);
                i--; 
            }
        }
    }
    
    @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(lista);
    }
    
    @Override
    public T buscar(Predicate<T> criterio) {
        for (int i = 0; i < lista.size(); i++) {
            T elem = lista.get(i);
            if (criterio.test(elem)) {
                return elem;
            }
        }
        return null;
    }
    
    @Override
    public void ordenar() {
        Collections.sort((List) lista); 
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        for (int i = 0; i < lista.size() - 1; i++) {
            for (int j = i + 1; j < lista.size(); j++) {
                if (comparador.compare(lista.get(i), lista.get(j)) > 0) {
                    T aux = lista.get(i);
                    lista.set(i, lista.get(j));
                    lista.set(j, aux);
                }
            }
        }
    }
    
    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            if (criterio.test(lista.get(i))) {
                resultado.add(lista.get(i));
            }
        }
        return resultado;
    }
    
    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> resultado = new ArrayList<>();
        for (int i = 0; i < lista.size(); i++) {
            resultado.add(operador.apply(lista.get(i)));
        }
        return resultado;
    }
    
    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;
        for (int i = 0; i < lista.size(); i++) {
            if (criterio.test(lista.get(i))) {
                contador++;
            }
        }
        return contador;
    }
    
    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ruta))) {
            out.writeObject(lista);
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(ruta))) {
            lista = (List<T>) in.readObject();
        }
    }

   
    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {

            bw.write(CriaturaJurasica.toHeaderCSV());
            bw.newLine();

            for (T elemento : lista) {
                bw.write(((CSVConvertible) elemento).toCSV());
                bw.newLine();
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        lista.clear(); 

        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty())
                    continue;
                T objeto = fromCSV.apply(linea.trim());
                lista.add(objeto);
            }
        }
    }

   
    


    
    
}
