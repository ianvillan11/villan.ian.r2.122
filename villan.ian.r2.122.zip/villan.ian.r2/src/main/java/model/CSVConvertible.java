
package model;

public interface CSVConvertible {
    String toCSV();
    static String toHeaderCSV() { return ""; }
}
