package model;


public enum Especie {
    TREX,
    VELOCIRAPTOR,
    TRICERATOPS,
    BRONTOSAURIO,
    PTERODACTILO
}
