
package model;

import java.io.Serializable;

public class CriaturaJurasica implements CSVConvertible, Comparable<CriaturaJurasica>,Serializable{
    
    private int id;
    private String nombre;
    private Especie especie;
    private int nivelPeligrosidad;   
    private int anioDescubrimiento;
    
    
    public CriaturaJurasica(int id, String nombre,Especie especie,int nivelPeligrosidad,int anioDescubrimiento){
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.nivelPeligrosidad = nivelPeligrosidad;
        this.anioDescubrimiento = anioDescubrimiento;
    }
    
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public Especie getEspecie() {
        return especie;
    }

    public int getNivelPeligrosidad() {
        return nivelPeligrosidad;
    }

    public int getAnioDescubrimiento() {
        return anioDescubrimiento;
    }
    
    @Override
    public String toString() {
        return "CriaturaJurasica{id=" + id + ", nombre='" + nombre + "', especie=" + especie + ", nivelPeligrosidad=" + nivelPeligrosidad + ", anioDescubrimiento=" + anioDescubrimiento + "}";
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + nivelPeligrosidad + "," + anioDescubrimiento;
    }
    
    public static String toHeaderCSV() {
        return "id,nombre,especie,nivelPeligrosidad,anioDescubrimiento";
    }

    public static CriaturaJurasica fromCSV(String linea) {
        String[] p = linea.split(",");

        int id = Integer.parseInt(p[0]);
        String nombre = p[1];
        Especie especie = Especie.valueOf(p[2]);
        int nivelPeligrosidad = Integer.parseInt(p[3]);
        int anioDescubrimiento = Integer.parseInt(p[4]);

        return new CriaturaJurasica(id, nombre, especie, nivelPeligrosidad, anioDescubrimiento);
    }
    
    @Override
    public int compareTo(CriaturaJurasica o) {

 
        if (this.nivelPeligrosidad != o.nivelPeligrosidad) {
            return Integer.compare(o.nivelPeligrosidad, this.nivelPeligrosidad);
        }

        return Integer.compare(this.anioDescubrimiento, o.anioDescubrimiento);
    }
}
