
package com.mycompany.villan.ian.r2;

import java.util.Comparator;
import java.util.List;
import model.Almacenable;
import model.CriaturaJurasica;
import model.Especie;
import model.Inventario;


public class VillanIanR2 {

    public static void main(String[] args) {
        try {
        Almacenable<CriaturaJurasica> inv = new Inventario<>();

        inv.agregar(new CriaturaJurasica(1, "Rexy", Especie.TREX, 10, 1905));
        inv.agregar(new CriaturaJurasica(2, "Blue", Especie.VELOCIRAPTOR, 7, 1924));
        inv.agregar(new CriaturaJurasica(3, "Spike", Especie.TRICERATOPS, 5, 1889));
        inv.agregar(new CriaturaJurasica(4, "Bronte", Especie.BRONTOSAURIO, 3, 1878));
        inv.agregar(new CriaturaJurasica(5, "SkyWing", Especie.PTERODACTILO, 6, 1911));
        inv.agregar(new CriaturaJurasica(6, "SwiftClaw", Especie.VELOCIRAPTOR, 8, 1930));

        System.out.println("=== Inventario original ===");
        for (CriaturaJurasica c : inv.obtenerTodos()) {
            System.out.println(c);
        }

        // 1) Orden natural (peligrosidad descendente)
        inv.ordenar();

        System.out.println("\n=== Orden natural ===");
        for (CriaturaJurasica c : inv.obtenerTodos()) {
            System.out.println(c);
        }

        // 2) Ordenar por nombre → completar Comparator
        inv.ordenar( Comparator.comparing(CriaturaJurasica::getNombre) );
        System.out.println("\n=== Ordenadas por nombre ===");
        for (CriaturaJurasica c : inv.obtenerTodos()) {
            System.out.println(c);
        }

        // 3) Filtrar peligrosidad >= 7 → completar Predicate
        System.out.println("\n=== Peligrosidad >= 7 ===");

        List<CriaturaJurasica> filtradas =
            inv.filtrar(c -> c.getNivelPeligrosidad() >= 7);

        for (CriaturaJurasica c : filtradas) {
            System.out.println(c);
        }

        // 4) Transformación: VELOCIRAPTOR con peligrosidad duplicada (+1, máx 10)
        System.out.println("\n=== Transformación de Velociraptors ===");

        List<CriaturaJurasica> transformadas =
            inv.transformar(c -> {

                if (c.getEspecie() == Especie.VELOCIRAPTOR) {

                    int nuevaPeligrosidad = (c.getNivelPeligrosidad() * 2) + 1;
                    if (nuevaPeligrosidad > 10) nuevaPeligrosidad = 10;

                    return new CriaturaJurasica(
                            c.getId(),
                            c.getNombre(),
                            c.getEspecie(),
                            nuevaPeligrosidad,
                            c.getAnioDescubrimiento()
                    );
                }

                return c; 
            });

        for (CriaturaJurasica c : transformadas) {
            System.out.println(c);
        }
        
        // 5) Contar criaturas descubiertas antes de 1900 → completar Predicate
        int antiguas = inv.contar(c -> c.getAnioDescubrimiento() < 1900);
        System.out.println("\nDescubiertas antes de 1900: " + antiguas);
        
        // 6) Persistencia
        inv.guardarEnBinario("src/main/java/resources/jurasico.bin");
        inv.guardarEnCSV("src/main/java/resources/jurasico.csv");
        /* inv.guardarEnJSON("data/jurasico.json"); */
       

        // 7) Cargar desde CSV → completar función fromCSV
        Almacenable<CriaturaJurasica> invCSV = new Inventario<>();

        invCSV.cargarDesdeCSV("src/main/java/resources/jurasico.csv", CriaturaJurasica::fromCSV);

        System.out.println("\n=== Inventario cargado desde CSV ===");
        for (CriaturaJurasica c : invCSV.obtenerTodos()) {
            System.out.println(c);
        }

    } catch (Exception e) {
        System.err.println("Error: " + e.getMessage());
    }
    }
}
